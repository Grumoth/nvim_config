require("nvim-dap-virtual-text").setup({
    enabled = true,
    show_logs = true,  -- Muestra los logs en el código
})